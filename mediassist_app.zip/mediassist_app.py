print("Hello from MediAssist!")
